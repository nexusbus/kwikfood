
import React, { useState } from 'react';
import { MOCK_COMPANIES } from '../constants';
import { Company } from '../types';

interface SuperAdminViewProps {
  onBack: () => void;
}

const SuperAdminView: React.FC<SuperAdminViewProps> = ({ onBack }) => {
  const [companies, setCompanies] = useState<Company[]>(MOCK_COMPANIES);

  return (
    <div className="bg-background-light min-h-screen">
      <header className="bg-white border-b border-gray-100 px-6 py-3 sticky top-0 z-50 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="size-8 bg-primary rounded-lg flex items-center justify-center text-white">
            <span className="material-symbols-outlined font-bold">shield_person</span>
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">KwikFood</h2>
            <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Super Admin</span>
          </div>
        </div>
        <button onClick={onBack} className="text-sm font-bold text-gray-400 hover:text-primary flex items-center gap-2">
           <span className="material-symbols-outlined">arrow_back</span>
           Voltar
        </button>
      </header>

      <main className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold">Gestão de Empresas</h2>
          <p className="text-gray-500">Registe e gira as parcerias de fast-food na plataforma KwikFood.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5">
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden sticky top-24">
              <div className="p-6 border-b border-gray-100 bg-gray-50/50">
                <h3 className="font-bold flex items-center gap-2 text-primary">
                  <span className="material-symbols-outlined">add_business</span>
                  Nova Empresa
                </h3>
              </div>
              <form className="p-6 space-y-5" onSubmit={(e) => e.preventDefault()}>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-1.5 tracking-wider">Nome da Empresa</label>
                  <input type="text" className="form-input w-full rounded-lg border-gray-200 focus:ring-primary focus:border-primary" placeholder="Ex: Burguer Express Angola" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-1.5 tracking-wider">NIF</label>
                    <input type="text" className="form-input w-full rounded-lg border-gray-200 focus:ring-primary focus:border-primary" placeholder="5401234567" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-1.5 tracking-wider">Localização</label>
                    <select className="form-select w-full rounded-lg border-gray-200 focus:ring-primary focus:border-primary">
                      <option>Luanda</option>
                      <option>Benguela</option>
                      <option>Huambo</option>
                    </select>
                  </div>
                </div>
                <div className="bg-primary/5 p-4 rounded-xl border border-primary/20">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-primary uppercase tracking-wider">Código Identificador</label>
                    <span className="text-[10px] bg-primary text-white px-2 py-0.5 rounded-full font-bold">GERADO AUTO</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="text" className="form-input w-full rounded-lg border-primary/30 bg-white text-center font-black text-2xl tracking-[0.2em]" readOnly value="B294" />
                    <button className="p-3 bg-white border border-primary/30 rounded-lg text-primary hover:bg-primary hover:text-white transition-all">
                      <span className="material-symbols-outlined">refresh</span>
                    </button>
                  </div>
                </div>
                <button className="w-full bg-primary text-white py-4 rounded-xl font-bold shadow-lg shadow-primary/20 hover:opacity-90 active:scale-95 transition-all">
                   REGISTAR EMPRESA
                </button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
               <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                 <h3 className="font-bold flex items-center gap-2">Empresas Cadastradas</h3>
                 <div className="relative">
                   <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">search</span>
                   <input type="text" className="form-input pl-9 py-1.5 text-xs rounded-lg border-gray-200" placeholder="Filtrar..." />
                 </div>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full text-left">
                   <thead className="bg-gray-50">
                     <tr className="text-[10px] font-black uppercase text-gray-400">
                       <th className="px-6 py-4">Empresa</th>
                       <th className="px-6 py-4 text-center">Código</th>
                       <th className="px-6 py-4">Status</th>
                       <th className="px-6 py-4 text-right">Ações</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-gray-100">
                     {companies.map(company => (
                       <tr key={company.id} className="hover:bg-gray-50 transition-colors">
                         <td className="px-6 py-4">
                           <p className="text-sm font-bold">{company.name}</p>
                           <p className="text-[10px] text-gray-400">NIF: {company.nif} | {company.location}</p>
                         </td>
                         <td className="px-6 py-4 text-center">
                           <span className="px-2 py-1 bg-gray-100 rounded text-xs font-black border border-gray-200">{company.id}</span>
                         </td>
                         <td className="px-6 py-4">
                           <div className="flex items-center gap-1.5 text-green-600 font-bold text-xs">
                             <span className="size-2 bg-green-500 rounded-full"></span>
                             Ativo
                           </div>
                         </td>
                         <td className="px-6 py-4 text-right space-x-2">
                           <button className="text-gray-400 hover:text-primary"><span className="material-symbols-outlined">edit</span></button>
                           <button className="text-gray-400 hover:text-primary"><span className="material-symbols-outlined">block</span></button>
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SuperAdminView;
