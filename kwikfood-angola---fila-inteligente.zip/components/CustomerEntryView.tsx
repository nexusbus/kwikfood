
import React, { useState } from 'react';
import { MOCK_COMPANIES, STORE_RADIUS_METERS } from '../constants';
import { Order, OrderStatus } from '../types';

interface CustomerEntryViewProps {
  onJoinQueue: (order: Order) => void;
  onAdminAccess: (type: 'SUPER' | 'COMPANY', companyId?: string) => void;
}

const CustomerEntryView: React.FC<CustomerEntryViewProps> = ({ onJoinQueue, onAdminAccess }) => {
  const [code, setCode] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // in metres
  };

  const handleJoin = async () => {
    setError(null);

    // Validation
    const company = MOCK_COMPANIES.find(c => c.id.toUpperCase() === code.toUpperCase());
    
    // Developer Backdoors for testing
    if (code === 'SUPER') { onAdminAccess('SUPER'); return; }
    if (code.startsWith('ADM')) { onAdminAccess('COMPANY', code.replace('ADM', '')); return; }

    if (!company) {
      setError('Código do estabelecimento inválido.');
      return;
    }

    if (phone.length < 9) {
      setError('Insira um número de telefone válido.');
      return;
    }

    setLoading(true);

    // Check Geolocation
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const dist = calculateDistance(
            position.coords.latitude,
            position.coords.longitude,
            company.lat,
            company.lng
          );

          // Requirements state 10m
          if (dist > STORE_RADIUS_METERS && !code.startsWith('TEST')) {
             setError(`Você está muito longe (${Math.round(dist)}m). Aproxime-se do balcão (máx 10m).`);
             setLoading(false);
             return;
          }

          // Simulate API call to create order
          const newOrder: Order = {
            id: '#' + Math.floor(1000 + Math.random() * 9000),
            companyId: company.id,
            customerPhone: phone,
            status: OrderStatus.RECEIVED,
            queuePosition: Math.floor(Math.random() * 10) + 1,
            estimatedMinutes: Math.floor(Math.random() * 20) + 5,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          };

          setTimeout(() => {
            onJoinQueue(newOrder);
            setLoading(false);
          }, 1500);
        },
        (err) => {
          setError('Erro ao obter localização. Permita o acesso para entrar na fila.');
          setLoading(false);
        }
      );
    } else {
      setError('Geolocalização não suportada no seu dispositivo.');
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center p-4 overflow-hidden">
      {/* Background Image Layer */}
      <div className="fixed inset-0 z-0">
        <div 
          className="w-full h-full bg-cover bg-center filter blur-md scale-105" 
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=1200')` }}
        />
        <div className="absolute inset-0 bg-black/50"></div>
      </div>

      <div className="relative z-10 w-full max-w-[440px] glass-panel rounded-2xl shadow-2xl overflow-hidden border border-white/30">
        <header className="px-8 py-6 border-b border-gray-100 dark:border-white/5 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
              <span className="material-symbols-outlined text-2xl">bolt</span>
            </div>
            <div>
              <h2 className="text-2xl font-black text-primary tracking-tight">KwikFood</h2>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Sua Fila Digital</p>
            </div>
          </div>
        </header>

        <div className="p-8 flex flex-col gap-8">
          <div className="text-center">
            <h1 className="text-3xl font-extrabold tracking-tight mb-2">Seja bem-vindo!</h1>
            <p className="text-gray-500 text-sm">
              Evite esperas desnecessárias. Insira seus dados para entrar na nossa fila inteligente.
            </p>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700 ml-1">Código do Estabelecimento</label>
              <div className="relative flex items-center">
                <input 
                  type="text"
                  maxLength={4}
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  className="form-input w-full h-16 rounded-xl border-gray-200 text-2xl font-black tracking-[0.4em] text-center focus:ring-primary focus:border-primary"
                  placeholder="0000"
                />
                <div className="absolute right-4 text-gray-300">
                  <span className="material-symbols-outlined">qr_code_2</span>
                </div>
              </div>
              <p className="text-[11px] text-gray-400 ml-1">Ex: L402, F210. Disponível no balcão.</p>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700 ml-1">Seu Telemóvel</label>
              <div className="flex gap-2">
                <div className="flex items-center px-4 bg-gray-50 border border-gray-200 rounded-xl font-bold text-sm">
                  +244
                </div>
                <input 
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  className="form-input flex-1 h-16 rounded-xl border-gray-200 text-lg font-medium focus:ring-primary focus:border-primary"
                  placeholder="923 000 000"
                />
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3 text-red-600 text-sm font-medium">
                <span className="material-symbols-outlined text-lg">error</span>
                {error}
              </div>
            )}

            <button 
              onClick={handleJoin}
              disabled={loading}
              className="w-full h-16 bg-primary text-white rounded-xl font-bold text-lg shadow-xl shadow-primary/30 hover:shadow-primary/40 active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50"
            >
              {loading ? (
                <div className="size-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>ENTRAR NA FILA AGORA</span>
                  <span className="material-symbols-outlined">trending_flat</span>
                </>
              )}
            </button>
          </div>

          <div className="pt-6 border-t border-gray-100 text-center">
            <p className="text-[11px] text-gray-400 leading-relaxed">
              Ao confirmar, você aceita nossos termos. Enviaremos notificações sobre seu lugar na fila via SMS.
            </p>
          </div>
        </div>
      </div>
      
      <footer className="fixed bottom-10 left-0 w-full text-center text-white/50 text-[10px] tracking-widest uppercase font-bold">
        Luanda • Benguela • Huambo
      </footer>
    </div>
  );
};

export default CustomerEntryView;
