
import React from 'react';
import { Order, OrderStatus } from '../types';
import { MOCK_COMPANIES } from '../constants';

interface CustomerTrackingViewProps {
  order: Order;
  onNewOrder: () => void;
}

const CustomerTrackingView: React.FC<CustomerTrackingViewProps> = ({ order, onNewOrder }) => {
  const company = MOCK_COMPANIES.find(c => c.id === order.companyId);
  const isPreparing = order.status === OrderStatus.PREPARING;
  const isReady = order.status === OrderStatus.READY;

  return (
    <div className="bg-background-light min-h-screen">
      <header className="flex items-center justify-between border-b border-gray-100 px-6 py-4 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="text-primary size-10 flex items-center justify-center bg-primary/5 rounded-xl">
            <span className="material-symbols-outlined text-2xl font-bold">fastfood</span>
          </div>
          <div>
            <h2 className="text-xl font-black tracking-tight text-primary">KwikFood</h2>
            <p className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-400">Angola</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs font-semibold text-gray-400 uppercase">{company?.location}</p>
          <p className="text-sm font-bold">Hoje, {order.timestamp}</p>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-kwik-green/10 text-kwik-green rounded-full mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-kwik-green opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-kwik-green"></span>
            </span>
            <span className="text-xs font-bold uppercase tracking-wider">Acompanhamento em Tempo Real</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-black tracking-tight mb-3">Seu pedido está a caminho!</h1>
          <p className="text-gray-500 max-w-md mx-auto italic">Relaxe, Kamba! Estamos cuidando de tudo para você saborear o melhor de {company?.location}.</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border border-gray-50 p-6 md:p-10 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-16">
            <div>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Identificação</p>
              <div className="flex items-baseline gap-2">
                <h2 className="text-6xl font-black text-primary">{order.id}</h2>
                <span className="text-gray-300 font-medium">/ {order.companyId}</span>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-gray-50 p-4 rounded-2xl">
              <span className="material-symbols-outlined text-kwik-orange text-3xl">schedule</span>
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase leading-none">Previsão</p>
                <p className="text-2xl font-black">{order.estimatedMinutes} min</p>
              </div>
            </div>
          </div>

          {/* Stepper */}
          <div className="relative px-2">
            <div className="absolute left-0 top-[26px] w-full h-1 bg-gray-100 rounded-full"></div>
            <div 
              className="absolute left-0 top-[26px] h-1 bg-primary rounded-full transition-all duration-1000"
              style={{ width: isReady ? '100%' : isPreparing ? '50%' : '15%' }}
            ></div>
            
            <div className="relative flex justify-between">
              <div className="flex flex-col items-center gap-4">
                <div className={`size-14 rounded-full flex items-center justify-center shadow-lg z-10 ${order.status === OrderStatus.RECEIVED ? 'bg-primary text-white' : 'bg-primary text-white opacity-60'}`}>
                  <span className="material-symbols-outlined text-2xl font-bold">check_circle</span>
                </div>
                <div className="text-center">
                  <p className="font-bold text-sm">Recebido</p>
                  <p className="text-[11px] text-gray-400">{order.timestamp}</p>
                </div>
              </div>

              <div className="flex flex-col items-center gap-4">
                <div className={`size-14 rounded-full flex items-center justify-center shadow-lg z-10 transition-all ${isPreparing ? 'bg-primary text-white ring-8 ring-primary/10 animate-soft-pulse' : 'bg-gray-100 text-gray-300'}`}>
                  <span className="material-symbols-outlined text-2xl font-bold">skillet</span>
                </div>
                <div className="text-center">
                  <p className={`font-bold text-sm ${isPreparing ? 'text-primary' : 'text-gray-400'}`}>Preparando</p>
                  <p className={`text-[11px] uppercase font-bold ${isPreparing ? 'text-primary' : 'text-gray-300'}`}>Na Cozinha</p>
                </div>
              </div>

              <div className="flex flex-col items-center gap-4">
                <div className={`size-14 rounded-full flex items-center justify-center shadow-lg z-10 ${isReady ? 'bg-primary text-white animate-bounce' : 'bg-gray-100 text-gray-300'}`}>
                  <span className="material-symbols-outlined text-2xl font-bold">shopping_bag</span>
                </div>
                <div className="text-center">
                  <p className={`font-bold text-sm ${isReady ? 'text-primary' : 'text-gray-400'}`}>Pronto</p>
                  <p className="text-[11px] text-gray-300">Aguardando</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Position Card */}
        <div className="bg-primary rounded-3xl p-8 text-white relative overflow-hidden mb-10 shadow-2xl shadow-primary/30">
          <div className="absolute -right-10 -top-10 size-40 bg-white/10 rounded-full blur-3xl"></div>
          <div className="relative z-10 flex flex-col items-center text-center">
            <div className="size-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6">
              <span className="material-symbols-outlined text-4xl font-bold">groups</span>
            </div>
            <p className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-white/70">Posição na Fila</p>
            <h3 className="text-4xl md:text-5xl font-black mb-4">
              Faltam <span className="text-white underline decoration-white/30 decoration-8 underline-offset-4">{order.queuePosition} pessoas</span>
            </h3>
            <p className="text-lg font-medium text-white/90">Kamba, já falta muito pouco para a sua vez!</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button className="flex items-center justify-center gap-3 bg-white hover:bg-gray-50 border-2 border-gray-100 font-bold py-5 px-6 rounded-2xl transition-all">
            <span className="material-symbols-outlined text-primary font-bold">receipt_long</span>
            Ver Detalhes do Pedido
          </button>
          <button 
            onClick={onNewOrder}
            className="flex items-center justify-center gap-3 bg-white hover:bg-gray-50 border-2 border-gray-100 font-bold py-5 px-6 rounded-2xl transition-all"
          >
            <span className="material-symbols-outlined text-primary font-bold">logout</span>
            Sair da Fila
          </button>
        </div>
      </main>
    </div>
  );
};

export default CustomerTrackingView;
