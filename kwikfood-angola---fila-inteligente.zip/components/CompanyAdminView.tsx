
import React, { useState } from 'react';
import { Company, Product, ProductStatus } from '../types';
import { MOCK_PRODUCTS } from '../constants';

interface CompanyAdminViewProps {
  company: Company;
  onLogout: () => void;
}

const CompanyAdminView: React.FC<CompanyAdminViewProps> = ({ company, onLogout }) => {
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [activeTab, setActiveTab] = useState('Todos');

  const filteredProducts = activeTab === 'Todos' 
    ? products 
    : products.filter(p => p.category === activeTab);

  return (
    <div className="flex h-screen bg-orange-50/30 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-orange-50 p-5 flex flex-col gap-6 hidden lg:flex">
        <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-2xl border border-orange-100">
          <div className="size-12 bg-primary rounded-xl flex items-center justify-center text-white">
             <span className="material-symbols-outlined text-3xl">restaurant</span>
          </div>
          <div className="flex flex-col overflow-hidden">
            <h1 className="text-sm font-black truncate">{company.name}</h1>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              <p className="text-green-600 text-[10px] font-black uppercase tracking-wider">Online Now</p>
            </div>
          </div>
        </div>

        <nav className="flex flex-col gap-1.5">
          <p className="text-[11px] font-black text-gray-400 px-4 mb-3 uppercase tracking-widest">Principais</p>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl bg-primary text-white shadow-lg shadow-primary/20">
            <span className="material-symbols-outlined">dashboard</span>
            <span className="text-sm font-bold">Visão Geral</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-500 hover:bg-orange-50 font-semibold transition-all">
            <span className="material-symbols-outlined">format_list_numbered</span>
            <span className="text-sm">Gestão de Fila</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-500 hover:bg-orange-50 font-semibold transition-all">
            <span className="material-symbols-outlined">restaurant_menu</span>
            <span className="text-sm">Produtos</span>
          </a>
          <hr className="my-5 border-orange-100" />
          <button onClick={onLogout} className="flex items-center gap-3 px-4 py-3 rounded-xl text-primary hover:bg-red-50 font-bold transition-all">
            <span className="material-symbols-outlined">logout</span>
            <span className="text-sm">Sair do Painel</span>
          </button>
        </nav>

        <div className="mt-auto p-5 bg-gradient-to-br from-primary to-orange-400 rounded-2xl text-white">
          <p className="text-[10px] font-black uppercase tracking-widest mb-2 opacity-90">Dica KwikFood</p>
          <p className="text-xs font-semibold leading-relaxed">Picos de pedidos ocorrem às 13h. Reforce a equipa da cozinha.</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8">
        <div className="max-w-[1200px] mx-auto">
          <header className="mb-10 flex items-end justify-between">
            <div>
              <h2 className="text-3xl font-black tracking-tight">Painel de Gestão</h2>
              <p className="text-gray-500 mt-1 italic">Gestão em tempo real da unidade {company.id}.</p>
            </div>
            <div className="bg-black text-white px-5 py-2.5 rounded-xl flex items-center gap-3 shadow-xl">
               <span className="text-xs font-bold opacity-60">LOJA</span>
               <span className="text-xl font-black tracking-widest">{company.id}</span>
            </div>
          </header>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {[
              { label: 'Pedidos Ativos', value: '12', trend: '+5% esta hora', color: 'primary', icon: 'pending_actions' },
              { label: 'Espera Média', value: '15 min', trend: '+2 min acima meta', color: 'secondary', icon: 'schedule' },
              { label: 'Vendas Hoje', value: 'Kz 145k', trend: '+10% vs ontem', color: 'green-500', icon: 'payments' },
              { label: 'Ticket Médio', value: 'Kz 4.2k', trend: 'Estável hoje', color: 'blue-500', icon: 'receipt_long' },
            ].map((stat, i) => (
              <div key={i} className={`bg-white rounded-2xl p-6 border-b-4 border-${stat.color} shadow-sm transition-transform hover:-translate-y-1`}>
                <div className="flex justify-between items-start mb-2">
                  <p className="text-gray-400 text-xs font-black uppercase tracking-wider">{stat.label}</p>
                  <span className={`material-symbols-outlined text-${stat.color}`}>{stat.icon}</span>
                </div>
                <p className="text-4xl font-black mb-2">{stat.value}</p>
                <p className={`text-[11px] font-black ${stat.trend.includes('+') ? 'text-green-600' : 'text-gray-400'}`}>{stat.trend}</p>
              </div>
            ))}
          </div>

          {/* Product Management */}
          <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-black flex items-center gap-3">
                <span className="material-symbols-outlined text-primary text-3xl">inventory_2</span>
                Gestão do Cardápio
              </h2>
              <button className="bg-primary text-white px-6 py-3 rounded-xl font-black text-sm shadow-xl shadow-primary/20 hover:scale-105 transition-all">
                ADICIONAR PRODUTO
              </button>
            </div>

            <div className="border-b border-orange-100 flex gap-10 overflow-x-auto">
              {['Todos', 'Hambúrgueres', 'Bebidas', 'Acompanhamentos'].map(tab => (
                <button 
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-4 pt-2 text-sm font-black uppercase tracking-widest transition-all border-b-4 ${activeTab === tab ? 'border-primary text-primary' : 'border-transparent text-gray-400'}`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {filteredProducts.map(product => (
                <div key={product.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-orange-50 group">
                  <div className="relative h-48">
                    <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent"></div>
                    <div className={`absolute top-3 right-3 text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest shadow-lg ${
                      product.status === ProductStatus.ACTIVE ? 'bg-green-500 text-white' : 
                      product.status === ProductStatus.LOW_STOCK ? 'bg-secondary text-white' : 'bg-red-600 text-white'
                    }`}>
                      {product.status.replace('_', ' ')}
                    </div>
                  </div>
                  <div className="p-5 flex flex-col gap-4">
                    <div>
                      <h3 className="font-black text-lg tracking-tight">{product.name}</h3>
                      <p className="text-primary font-black text-xl mt-1">Kz {product.price.toLocaleString()}</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="flex-1 bg-black text-white px-4 py-2.5 rounded-xl text-xs font-black hover:bg-primary transition-colors">
                        EDITAR
                      </button>
                      <button className="p-2.5 text-gray-400 hover:text-primary transition-colors">
                        <span className="material-symbols-outlined">visibility_off</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CompanyAdminView;
