
import { Company, Product, ProductStatus, OrderStatus } from './types';

export const MOCK_COMPANIES: Company[] = [
  { id: 'L402', name: 'Burguer King Angola', location: 'Luanda Shopping', nif: '540293122', lat: -8.839988, lng: 13.289437 },
  { id: 'F210', name: 'Franguito de Luanda', location: 'Talatona', nif: '541002931', lat: -8.9161, lng: 13.1895 },
  { id: 'P019', name: 'Pizza Nosso Lar', location: 'Benguela', nif: '548812001', lat: -12.5763, lng: 13.4055 },
];

export const MOCK_PRODUCTS: Product[] = [
  { id: '1', name: 'Kwik Classic XL', price: 4500, category: 'Hambúrgueres', status: ProductStatus.ACTIVE, imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=400' },
  { id: '2', name: 'Kwik Double Angola', price: 5200, category: 'Hambúrgueres', status: ProductStatus.ACTIVE, imageUrl: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&q=80&w=400' },
  { id: '3', name: 'Kwik Fries G', price: 1800, category: 'Acompanhamentos', status: ProductStatus.LOW_STOCK, imageUrl: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&q=80&w=400' },
  { id: '4', name: 'Kwik Milkshake', price: 2500, category: 'Bebidas', status: ProductStatus.OUT_OF_STOCK, imageUrl: 'https://images.unsplash.com/photo-1579954115545-a95591f28be0?auto=format&fit=crop&q=80&w=400' },
];

export const STORE_RADIUS_METERS = 10;
