
import React, { useState, useEffect } from 'react';
import { AppView, Company, Order, OrderStatus } from './types';
import { MOCK_COMPANIES } from './constants';
import SuperAdminView from './components/SuperAdminView';
import CompanyAdminView from './components/CompanyAdminView';
import CustomerEntryView from './components/CustomerEntryView';
import CustomerTrackingView from './components/CustomerTrackingView';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>('CUSTOMER_ENTRY');
  const [activeCompany, setActiveCompany] = useState<Company | null>(null);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // Simple Router based on state
  const renderView = () => {
    switch (currentView) {
      case 'SUPER_ADMIN':
        return <SuperAdminView onBack={() => setCurrentView('CUSTOMER_ENTRY')} />;
      case 'COMPANY_ADMIN':
        return <CompanyAdminView 
          company={activeCompany || MOCK_COMPANIES[0]} 
          onLogout={() => setCurrentView('CUSTOMER_ENTRY')} 
        />;
      case 'CUSTOMER_TRACKING':
        return <CustomerTrackingView 
          order={activeOrder!} 
          onNewOrder={() => {
            setActiveOrder(null);
            setCurrentView('CUSTOMER_ENTRY');
          }} 
        />;
      case 'CUSTOMER_ENTRY':
      default:
        return <CustomerEntryView 
          onJoinQueue={(order) => {
            setActiveOrder(order);
            setCurrentView('CUSTOMER_TRACKING');
          }}
          onAdminAccess={(type, companyId) => {
            if (type === 'SUPER') {
              setCurrentView('SUPER_ADMIN');
            } else {
              const co = MOCK_COMPANIES.find(c => c.id === companyId);
              setActiveCompany(co || MOCK_COMPANIES[0]);
              setCurrentView('COMPANY_ADMIN');
            }
          }}
        />;
    }
  };

  return (
    <div className="min-h-screen">
      {renderView()}
    </div>
  );
};

export default App;
